<?php
error_reporting(0);
session_start();
include"simple_html_dom.php";
include"curl.php";
include"php_headers.php";
$html=new simple_html_dom();

?>
<!DOCTYPE html>
<html lang="zxx">

<head>
	<title>Crawler:: website</title>
	<!-- custom-theme -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Downy Shoes Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script type="application/x-javascript">
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<!-- //custom-theme -->
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link rel="stylesheet" href="css/shop.css" type="text/css" media="screen" property="" />
	<link href="style/loginstyle.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/style7.css" rel="stylesheet" type="text/css" media="all" />
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<!-- font-awesome-icons -->
	<link href="css/font-awesome.css" rel="stylesheet">
<link href="css/newstyle.css" rel="stylesheet">
	<!-- //font-awesome-icons -->
	<link href="//fonts.googleapis.com/css?family=Montserrat:100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800"
	    rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800" rel="stylesheet">
</head>

<body>
	<!-- banner -->
	<div class="banner_top" id="home">
		<div class="wrapper_top_w3layouts">

			<div class="header_agileits">
				<div class="logo">
					<h1><a class="navbar-brand" href="?page=home"><span>Shoes</span> <i>Crawler</i></a></h1>
				</div>
				<div class="overlay overlay-contentpush">
					<button type="button" class="overlay-close"><i class="fa fa-times" aria-hidden="true"></i></button>
<script type="text/javascript">
	
	function showul()
	{
		$("#ulid").show();
	}
	function hideul()
	{
		$("#ulid").hide();
	}
</script>
<style type="text/css">
	
</style>
					<nav>
						<ul>
							<li><a href="?page=home" class="active">Home</a></li>
							<li><a href="?page=signup">Signup</a></li>
							<li><a href="?page=login">Signin</a></li>
							<li onmouseover="showul();" onmouseout="hideul();"><a href="#">Shoes from <i class="fa fa-caret-down"></i></a>
<ul class="dropdown-menu" id="ulid" style="text-align:center;display:none;">
      <li><a href="?page=puma">puma</a></li>
      <li><a href="?page=pak">pakstyle</a></li>
      <li><a href="?page=sport">thesportstore</a></li>
    </ul>

							
							
							
						</ul>

						
					</nav>
					
				</div>
				<div class="mobile-nav-button">
					<button id="trigger-overlay" type="button"><i class="fa fa-bars" aria-hidden="true"></i></button>
				</div>
				<!-- cart details
				<div class="top_nav_right">
					<div class="shoecart shoecart2 cart cart box_1">
						<form action="#" method="post" class="last">
							<input type="hidden" name="cmd" value="_cart">
							<input type="hidden" name="display" value="1">
							<button class="top_shoe_cart" type="submit" name="submit" value=""><i class="fa fa-cart-arrow-down" aria-hidden="true"></i></button>
						</form>
					</div>

				</div> -->
				<!-- //cart details -->
				<!-- search -->
				<div class="search_w3ls_agileinfo">
					<div class="cd-main-header">
						<ul class="cd-header-buttons">
							<li><a class="cd-search-trigger" href="#cd-search"> <span></span></a></li>
						</ul>
					</div>
					<div id="cd-search" class="cd-search" style="top: 92px;">
						 
<style type="text/css">
	.cd-search{
    border-radius: 0;
    border: none;
    background: rgba(0, 0, 0, 0.75);
    width: 100%;
    -webkit-appearance: none;
    -moz-appearance: none;
    -ms-appearance: none;
    -o-appearance: none;
    appearance: none;
    font-size: 1em;
    padding:18px;
    color: #fff;
    letter-spacing: 3px;
}


</style>

    <div class="header-input col-sm-12 ">
      <form method="post">
        <span class="search_span col-sm-4 " >
        <input type="text"  name="search" placeholder="I want to search...." class="form-control" />
        </span>
<span class="col-sm-4">
  
                    
<select name="selectweb" class="cd-search  search_span " style="    width: 300px;">
  <option value="">choose website</option>
  <option value="puma.us">puma</option>
<option value="pakstyle.pk">PakStyle.pk</option>
  <option value="sport">thesportstore.pk</option>
  




</select>

<div class="col-sm-1-"></div>


</span>
         <span class="search_span col-sm-2 ">
       <input type="submit" name="searchbtn" value="Crawl" class="btn btn-success" style="padding: 18px"  onclick="hide_with_out_search_div()" />
        </span>
      </form>
    </div>
  >
					</div>
				</div>
				<!-- //search -->

				<div class="clearfix"></div>
			</div>
<?php 

if($_GET['page']!='home')
{
	
?>

<div class="banner_top innerpage" id="home">
		<div class="wrapper_top_w3layouts">
			
		</div>
		<!-- //cart details -->
		<!-- search -->
	
		<!-- //search -->
		<div class="clearfix"></div>
		<!-- /banner_inner -->
		<div class="services-
		breadcrumb_w3ls_agileinfo">
			<div class="inner_breadcrumb_agileits_w3">

				<ul class="short">
					<li><a href="?page=home">Home</a><i>|</i></li>
					<?php
					if(!$_SESSION['email']){ 
					?>
					<li><a href="?page=login" style="color: white">login</a></li>
				<?php }

				if($_SESSION['email']){ 
					?>
					<li><a href="?page=logout" style="color: white">logout</a></li>
				<?php }?>
				</ul>
			</div>
		</div>
		<!-- //banner_inner -->
	</div>
	<?php
	} 
	?>

			<!-- /slider -->
				<?php if($_GET['page']=='home')
{
?>
			<div class="slider">
				<div class="callbacks_container">
					<ul class="rslides callbacks callbacks1" id="slider4">

						<li>
							<div class="banner-top2">
								<div class="banner-info-wthree">
									<h3>Nike</h3>
									<p>See how good they feel.</p>

								</div>

							</div>
						</li>
						<li>
							<div class="banner-top1">
								<div class="banner-info-wthree">
									<h3>Adidas</h3>
									<p>For All Walks of Life.</p>

								</div>

							</div>
						</li>
						<li>
							<div class="banner-top">
								<div class="banner-info-wthree">
									<h3>Sneakers</h3>
									<p>See how good they feel.</p>

								</div>

							</div>
						</li>
						<li>
							<div class="banner-top1">
								<div class="banner-info-wthree">
									<h3>Adidas</h3>
									<p>For All Walks of Life.</p>

								</div>

							</div>
						</li>
					</ul>
				</div>
				<div class="clearfix"> </div>

			</div>
			<?php } 
			?>
			<!-- //slider -->
		
		</div>
	</div>


	<div class="modal fade" id="myModal2" tabindex="-1" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      
      <div class="modal-body modal-body-sub_agile">
        <div class="col-md-8 modal_body_left modal_body_left1">
         <div class="logo" style="position: relative;">
					<h1><a  style="background: black; border:2px solid black; margin-bottom: 20px; height: 54px" class="navbar-brand" href="?page=home"><span>Please</span> <i>Login</i></a></h1>
				</div>
				<div class="clearfix"></div>
          <form  method="post">
            
            <div class="styled-input">
              <label class="signlable">Email</label>
              <input type="email" class="nodeinput" style="width: 100%" name="email1" required>
              <span></span></div>
            <div class="styled-input">
              <label class="signlable">Password</label>
              <input type="password" class="nodeinput" style="width: 100%" name="password1" required>
              <span></span></div>
            
            <input type="submit" name="signup" class="btn btn-primary" value="login" style="margin-top:10px;">
          </form>
          <div class="clearfix"></div>
        </div>
        <div class="col-md-4">
        	
<img src="images/login.jpg" class="img-responsive img-rounded img-thumbnail">

        </div>
        <div class="clearfix"></div>
      </div>
    </div>
    <!-- //Modal content-->
  </div>
</div>
