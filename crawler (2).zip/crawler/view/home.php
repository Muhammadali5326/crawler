<div class="grids_bottom">
		<div class="style-grids">
			<div class="col-md-6 style-grid style-grid-1">
				<img src="images/b1.jpg" alt="shoe">
			</div>
		</div>
		<div class="col-md-6 style-grid style-grid-2">
			<div class="style-image-1_info">
				<div class="style-grid-2-text_info">
					<h3>Puma</h3>
					<p> PUMA. PUMA is a German sportswear brand, best known for its athletic apparel and various sportswear goods; founded by Rudolf Dassler in 1924.</p>
					<div class="shop-button">
						<a href="?page=puma">See now</a>
					</div>
				</div>
			</div>
			<div class="style-image-2">
				<img src="images/b2.jpg" alt="shoe">
				<div class="style-grid-2-text">
					<h3>The Best Shoes</h3>
				</div>
			</div>
		</div>
		<div class="clearfix"></div>
	</div>
	
	<!-- //grids_bottom-->
	<!-- /girds_bottom2-->
	<div class="grids_sec_2">
		
			<div class="col-md-6" style="    padding: 0px;">
				<div class="grid_sec_info">
					<div class="style-grid-2-text_info">
						<h3>Pakstyle</h3>
						<p>pak style provides variety of shoes to its customers to satisfy their demand.</p>
						<div class="shop-button">
							<a href="?page=pak">See now</a>
						</div>
					</div>
				</div>
				<div class="style-image-2">
					<img src="images/b4.jpg" class="img-responsive" alt="shoe">
					<div class="style-grid-2-text">
						<h3>Get in now</h3>
					</div>
				</div>
			</div>
			<div class="col-md-6" style="    padding: 0px;">

				<div class="style-image-2">
					<img src="images/b3.jpg" class="img-responsive" alt="shoe">
					<div class="style-grid-2-text">
						<h3>Nice looks</h3>
					</div>
				</div>
				<div class="grid_sec_info last">
					<div class="style-grid-2-text_info">
						<h3>thesportstore</h3>
						<p>thesportstore provides variety of shoes to its customers to satisfy their demand.</p>
						<div class="shop-button two">
							<a href="?page=sport">See Now</a>
						</div>
					</div>
				</div>
			</div>
			<div class="clearfix"></div>
		
	</div>
	<!-- //grids_bottom2-->
	<!-- /Properties -->
	
	<!--//banner -->

	<!-- /newsletter-->
	<div class="newsletter_w3layouts_agile">
		<div class="col-sm-6 newsleft">
			<h3>Sign up for Newsletter !</h3>
		</div>
		<div class="col-sm-6 newsright">
			<form action="#" method="post">
				<input type="email" placeholder="Enter your email..." name="email" required="">
				<input type="submit" value="Submit">
			</form>
		</div>

		<div class="clearfix"></div>
	</div>