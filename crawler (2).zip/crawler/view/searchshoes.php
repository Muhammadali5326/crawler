<?php 
$search=$_GET['search'];
$target=$_GET['target'];
$items=[];
//////////////////////////////////puma search starts ////////////////////////////////////
if($target=='puma.us' && $search!="" )
{

?>
      <input type="text" value="you have searched '<?php echo $search ?>' from <?php echo 
      $target?>"  style="border:1px solid #ebebeb; border-radius:0px; margin-bottom:20px; color:tomato; width:100%; font-size:18px; height:40px;padding:20px" readonly="readonly" />
      <?php 

	 $html->load(curl('https://us.puma.com/en/us/search?q='.$search));

foreach($html->find('div[class=grid-tile col-6 col-sm-4 col-md-3]') as $key)
{
	


		
$item['name']= $key->find('div[class=pdp-link] a ',0)->innertext;
	$name=html_entity_decode(trim($item['name']));
		//echo $name."<br>";


	$price['price']= $key->find('span[class=sales] span[class=value] ',0)->plaintext;
	$prices=html_entity_decode(trim($price['price']));
	//echo $prices."<br>";

	$off['off']= $key->find('span[class=strike-through list] span ',0)->plaintext;
	$offprice=html_entity_decode(trim($off['off']));
	//echo $offprice."<br>";


		$realprice=str_replace("$","",$prices);
 		"<b>";
 		$realoff=str_replace("$","",$offprice);	
 		"<b>";
	
 $sale=100-(($realprice/$realoff)*100);
 $sale=ceil($sale);


$imgurl['imgurl']= $key->find('div[class=image-container] a img',0)->getAttribute('src');
$image=html_entity_decode(trim($imgurl['imgurl']));
	

?>

<div class="col-md-3" style="overflow: hidden;">
  <div class="product-shoe-info shoe">
    <div class="men-pro-item">
      <div class="men-thumb-item"> <img src="<?php echo $image ?>" class=" img-responsive" style="height:175px; width:300px" />
        <?php if($offprice){?>
        <span class="product-new-top" style="background:red; border:1px solid white; color:white; font-family: sans-serif;"><?php echo $sale." %off";  ?></span>
        <?php } 
		?>
      </div>
      <div class="item-info-product">
        <h4> <a href="#"><?php echo "
<p style='          text-align: left;
    overflow: hidden;
    margin-top: 13px;
    padding: 0px;
    font-size: 12px;
    width: 194px;
    height: 24px;
    font-weight: initial;
    font-family: sans-serif;'>".$name."</p>"; ?> </a> </h4>
        <div class="info-product-price">
          <div class="grid_meta">
            <div class="product_price">
              <div class="col-sm-6 "> <span class="money" style="color: green"> <?php echo $prices; ?> </span></div>
              <div class="col-sm-6 "> <?php echo '<del style="color:red">'.$offprice.'</del>'; ?> </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="clearfix"></div>
  </div>
</div>
<?php







	}

}
//////////////////////////////////puma search ends ////////////////////////////////////

//////////////////////////////////pakstyle search starts ////////////////////////////
elseif($target=='pakstyle.pk' && $search!="")

{
 ?>
      <input type="text" value="you have searched '<?php echo $search ?>' from <?php echo 
      $target?>"  style="border:1px solid #ebebeb; border-radius:0px; margin-bottom:20px; color:tomato; width:100%; font-size:18px; height:40px;padding:20px" readonly="readonly" />
      <?php 

		$html->load(curl("https://www.pakstyle.pk/search/$search"));

foreach($html->find('div[class=single-product]') as $key)
{
	$out['out']= $key->find('div[class=pro-content text_ac] span  b ',0)->plaintext;
	$stock=html_entity_decode(trim($out['out']));
	//echo $name."<br>";
	 if($stock!='Out of Stock')
	 { 
		
$item['name']= $key->find('div[class=pro-content text_ac] p  b ',0)->innertext;
	$name=html_entity_decode(trim($item['name']));
	//echo $name."<br>";
	
	

	
	
	$price['amount']= $key->find('div[class=pro-content text_ac] p  span ',0)->plaintext;
	$amount=html_entity_decode(trim($price['amount']));
	
	
	$real_amount=str_replace("Rs.","",$amount);
	//echo $amount."<br>";
	
$del['del']= $key->find('div[class=pro-content text_ac] p  del ',0)->plaintext;
	$disc=html_entity_decode(trim($del['del']));
	$real_disc=str_replace("Rs.","",$disc);
	//echo $disc."<br>";
	
 $off=100-(($real_amount/$real_disc)*100);

	$img['image']= $key->find('div[class=pro-img] img',0)->getAttribute('src');
	$image=html_entity_decode(trim($img['image']));
	
	//echo $image."</br>";
	?>
<div class="col-md-3" style="overflow: hidden;">
  <div class="product-shoe-info shoe">
    <div class="men-pro-item">
      <div class="men-thumb-item"> <img src="<?php echo $image ?>" class=" img-responsive" style="height:175px; width:300px" /> <span class="product-new-top" style="background:red; border:1px solid white; color:white; font-family: sans-serif;"><?php echo ceil($off)." %off";  ?></span> </div>
      <div class="item-info-product">
        <h4> <a href="#"><?php echo "
<p style='          text-align: left;
    overflow: hidden;
    margin-top: 13px;
    padding: 0px;
    font-size: 12px;
    width: 194px;
    height: 24px;
    font-weight: initial;
    font-family: sans-serif;'>".$name."</p>"; ?> </a> </h4>
        <div class="info-product-price">
          <div class="grid_meta">
            <div class="product_price">
              <div class="col-sm-6 "> <span class="money" style="color: green"> <?php echo $amount; ?> </span></div>
              <div class="col-sm-6 "> <?php echo '<del style="color:red">'.$disc.'</del>'; ?> </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="clearfix"></div>
  </div>
</div>
<?php
	 }
	else
	{}
}}
	
	//////////////////////////////////pakstyle search ends  //////////////////////////


//////////////////////////////thesports search starts  //////////////////////////
elseif($target=='sport' && $search!="")

{

?>
      <input type="text" value="you have searched '<?php echo $search ?>' from <?php echo 
      $target?>"  style="border:1px solid #ebebeb; border-radius:0px; margin-bottom:20px; color:tomato; width:100%; font-size:18px; height:40px;padding:20px" readonly="readonly" />
      <?php 

$html->load(curl('http://thesportstore.pk/index.php?route=product/search&search='.$search.''));
 

foreach($html->find('div[class=product-list-item]') as $key)
{
	$out['out']= $key->find('div[class=product-thumb outofstock] p[class=price]',0)->innertext;
	$outofstock=html_entity_decode(trim($out['out']));
	//echo $outofstock;
	if(!$outofstock)
		{
$item['name']= $key->find('div[class=caption] a',0)->plaintext;
	$name=html_entity_decode(trim($item['name']));
	//echo $name."<br>";
	

	
	
	
	$price['amount']= $key->find('div[class=caption] p[class=price] span[class=price-new]',0)->innertext;
	$amount=html_entity_decode(trim($price['amount']));



	$just['just']= $key->find('p[class=price]',0)->innertext;
	$justamount=html_entity_decode(trim($just['just']));
	
	//echo $amount."<br>";
	

	
	$img['image']= $key->find('img[class=lazy first-image]',0)->getAttribute('data-src');
	$image=html_entity_decode(trim($img['image']));
	

	$sale['sale']=  $key->find('span[class=label-sale] b',0)->innertext;
	$amountsale=html_entity_decode(trim($sale['sale'])); 

	$oldprice['oldprice']= $key->find('span[class=price-old]',0)->innertext;
	$amount1=html_entity_decode(trim($oldprice['oldprice']));	


	?>
    <div class="col-sm-3 maindiv">
  <?php if($amountsale){ 
?>
  <span class="off"><?php echo $amountsale; ?>off</span>
  <?php } ?>
  <span class="clearfix"></span> <img src="<?php echo $image ?>" class="img-thumbnail img-responsive" style="height:250px; width:300px" /> <span class="clearfix"></span> <?php echo "<p style='  text-align:center;   overflow: hidden;
    padding: 0px;
    width: 200px;
    height: 20px;'>".$name."</p>"; ?> <span class="clearfix"></span>
  <?php if(!$amountsale){ ?>
  <span class="col-sm-6"> <?php echo "<b style='color:#57585c'>".$justamount."</b>"; ?> </span>
  <?php 
}
else
{?>
  <span class="col-sm-6"> <?php echo "<b style='color:#57585c'>".$amount."</b>"; ?> </span>
  <?php 

}


if($amountsale){ ?>
  <span class="col-sm-6"> <?php echo "<b><del style='color:red'>".$amount1."</del></b>"; ?> </span>
  <?php }


 ?>
  </span> </div>
    <?php

}

}	

}

//////////////////////////////////thesports search ends /////////////////////////////////

//////////////////////////////////No search////////////////////////////////////
else
{
echo"<h3 style='color:tomato;text-align:center'>results not found!</h3>";

}

?>